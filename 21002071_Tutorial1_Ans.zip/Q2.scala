object second{   
    def main(args: Array[String]): Unit ={
        print("35C in Farenhite: ")
        println(tofarenhite(35))
    }


    def tofarenhite(x:Int) : Double = x*1.8 + 32.0
}