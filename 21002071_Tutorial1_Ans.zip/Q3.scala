object third{
    def main(args: Array[String]) : Unit =
        print("Volume of a Sphere with radius 5 is: ")
        println(Volume(5))

    def Volume(x:Int) : Double = (4/3.0)*3.14*x*x*x
}