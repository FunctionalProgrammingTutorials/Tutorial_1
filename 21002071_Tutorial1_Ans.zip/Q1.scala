object first{
    def main(args: Array[String]): Unit ={
        print("Area of a Disk with radius 5 is: ")
        println(Area(5))
    }

    def Area(x:Int) : Double = 3.14*x*x
}   
    

