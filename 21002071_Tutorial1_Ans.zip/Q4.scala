object fourth{
    def main(args: Array[String]) : Unit ={
        var wholesale = 24.95 + Discount() + ShippingCost(50)
        print("Price of a book with 60 pages: Rs.")
        println(wholesale)
    }


    def Discount() : Double = 24.95*0.4

    def ShippingCost(x:Int) : Double = if x>50 then 3+(x-50)*0.75 else 3

}