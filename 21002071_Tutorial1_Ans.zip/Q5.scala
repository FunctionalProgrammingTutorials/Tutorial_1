object fifth{
    def main(args: Array[String]) : Unit ={
        var totalTime = time(2, 8) + time(3, 7) + time(2, 8)
        print("Time Taken to reach the Home: ")
        print(totalTime)
        println("min")
    }


    def time(x:Int, y:Int) : Int = x*y
}